import wx
from goole_tool_design import GoogleTool
import logging


app = wx.App()
frame = GoogleTool(None)
frame.Show()
app.MainLoop()