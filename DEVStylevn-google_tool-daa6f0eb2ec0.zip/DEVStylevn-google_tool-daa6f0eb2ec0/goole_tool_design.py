# -*- coding: utf-8 -*-
import os
import time
from threading import Thread
###########################################################################
## Python code generated with wxFormBuilder (version Jun 17 2015)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################
import requests
from requests_html import HTMLSession
from bs4 import BeautifulSoup
import wx
import wx.xrc
import yaml
import json
import logging

###########################################################################
## Class google_tool
###########################################################################
config_file = os.path.join(os.path.dirname(__file__), 'config.yml')
config = None
with open(config_file) as f:
    config = yaml.safe_load(f)

logging.basicConfig(filename="google_log.txt",
                    filemode='a',
                    format='%(asctime)s,%(msecs)d %(name)s %(levelname)s %(message)s',
                    datefmt='%H:%M:%S',
                    level=logging.INFO | logging.ERROR)


class GoogleTool(wx.Frame):

    def __init__(self, parent):
        self.thread_search = None
        wx.Frame.__init__(self, parent, id=wx.ID_ANY, title=u"Google tools - Beecode.online", pos=wx.DefaultPosition,
                          size=wx.Size(721, 500), style=wx.DEFAULT_FRAME_STYLE | wx.TAB_TRAVERSAL)
        self.SetMinSize(wx.Size(721, 500))
        self.SetSizeHintsSz(wx.Size(721, 500), wx.DefaultSize)
        self.SetFont(wx.Font(11, 73, 90, 90, False, wx.EmptyString))
        self.SetBackgroundColour(wx.SystemSettings.GetColour(wx.SYS_COLOUR_ACTIVECAPTION))

        self.menu_bar = wx.MenuBar(0)
        self.tools = wx.Menu()
        self.update_menu = wx.MenuItem(self.tools, wx.ID_ANY, u"Update", u"update when has a new version",
                                       wx.ITEM_NORMAL)
        self.tools.AppendItem(self.update_menu)

        self.menu_bar.Append(self.tools, u"tools")

        self.about = wx.Menu()
        self.menu_bar.Append(self.about, u"about !")

        self.SetMenuBar(self.menu_bar)

        main_sz = wx.BoxSizer(wx.VERTICAL)

        config_sz = wx.StaticBoxSizer(wx.StaticBox(self, wx.ID_ANY, u"Configuration"), wx.VERTICAL)

        input_0 = wx.BoxSizer(wx.HORIZONTAL)

        self.label = wx.StaticText(config_sz.GetStaticBox(), wx.ID_ANY, u"API url Get Key Word :", wx.DefaultPosition,
                                   wx.DefaultSize, wx.ALIGN_CENTRE)
        self.label.Wrap(-1)
        input_0.Add(self.label, 0, wx.TOP | wx.BOTTOM | wx.LEFT, 9)

        self.input_get_key_work_url = wx.TextCtrl(config_sz.GetStaticBox(), wx.ID_ANY, wx.EmptyString,
                                                  wx.DefaultPosition,
                                                  wx.DefaultSize, wx.TE_AUTO_URL)
        input_0.Add(self.input_get_key_work_url, 1, wx.TOP | wx.BOTTOM | wx.RIGHT, 5)

        config_sz.Add(input_0, 1, wx.EXPAND, 5)

        input_01 = wx.BoxSizer(wx.HORIZONTAL)

        self.input_post_result_search_lable = wx.StaticText(config_sz.GetStaticBox(), wx.ID_ANY,
                                                            u"API url Push Results :", wx.DefaultPosition,
                                                            wx.DefaultSize, wx.ALIGN_CENTRE)
        self.input_post_result_search_lable.Wrap(-1)
        input_01.Add(self.input_post_result_search_lable, 0, wx.TOP | wx.BOTTOM | wx.LEFT, 9)

        self.input_post_result_search = wx.TextCtrl(config_sz.GetStaticBox(), wx.ID_ANY, wx.EmptyString,
                                                    wx.DefaultPosition,
                                                    wx.DefaultSize, wx.TE_AUTO_URL)
        input_01.Add(self.input_post_result_search, 1, wx.TOP | wx.BOTTOM | wx.RIGHT, 5)

        config_sz.Add(input_01, 1, wx.EXPAND, 5)

        # Token
        input_02 = wx.BoxSizer(wx.HORIZONTAL)

        self.token = wx.StaticText(config_sz.GetStaticBox(), wx.ID_ANY,
                                   u"Token :", wx.DefaultPosition,
                                   wx.DefaultSize, wx.ALIGN_CENTRE)
        self.token.Wrap(-1)
        input_02.Add(self.token, 0, wx.TOP | wx.BOTTOM | wx.LEFT, 9)

        self.input_token = wx.TextCtrl(config_sz.GetStaticBox(), wx.ID_ANY, wx.EmptyString,
                                       wx.DefaultPosition,
                                       wx.DefaultSize, wx.TE_AUTO_URL)
        input_02.Add(self.input_token, 1, wx.TOP | wx.BOTTOM | wx.RIGHT, 5)

        config_sz.Add(input_02, 1, wx.EXPAND, 5)
        # End Token

        main_sz.Add(config_sz, 0, wx.ALL | wx.EXPAND, 5)

        control_sz = wx.StaticBoxSizer(wx.StaticBox(self, wx.ID_ANY, u"Controls"), wx.VERTICAL)
        bSizer8 = wx.BoxSizer(wx.HORIZONTAL)

        self.run_btn = wx.Button(control_sz.GetStaticBox(), wx.ID_ANY, u"Run", wx.DefaultPosition, wx.DefaultSize, 0)
        self.run_btn.SetBackgroundColour(wx.Colour(0, 128, 64))

        bSizer8.Add(self.run_btn, 0, wx.ALL, 5)

        self.label_running = wx.StaticText(control_sz.GetStaticBox(), wx.ID_ANY, u"Running ...", wx.DefaultPosition,
                                           wx.DefaultSize, 0)
        self.label_running.Wrap(-1)
        self.label_running.SetForegroundColour(wx.Colour(255, 0, 0))
        self.label_running.SetBackgroundColour(wx.Colour(255, 255, 0))

        bSizer8.Add(self.label_running, 0, wx.ALL, 9)

        control_sz.Add(bSizer8, 1, wx.EXPAND, 5)

        main_sz.Add(control_sz, 1, wx.EXPAND, 5)
        Data = wx.StaticBoxSizer(wx.StaticBox(self, wx.ID_ANY, u"label"), wx.VERTICAL)
        self.list_result = wx.ListCtrl(self, style=wx.LC_REPORT)
        self.list_result.InsertColumn(0, "No.")
        self.list_result.InsertColumn(1, "Top")
        self.list_result.InsertColumn(2, "Key")
        self.list_result.InsertColumn(3, "Link")
        self.list_result.InsertColumn(4, "Post to Server")
        self.list_result.Arrange()
        Data.Add(self.list_result, 1, wx.ALL | wx.EXPAND, 5)
        main_sz.Add(Data, 1, wx.EXPAND, 5)
        self.SetSizer(main_sz)
        self.Layout()

        self.Centre(wx.BOTH)

        # Connect Events
        self.input_get_key_work_url.Bind(wx.EVT_TEXT, self.input_get_key_work_change_path)
        self.input_post_result_search.Bind(wx.EVT_TEXT, self.input_push_key_work_change_path)
        self.run_btn.Bind(wx.EVT_BUTTON, self.btn_run)
        self.label_running.Hide()
        self.input_get_key_work_url.SetValue(config['api_get_keyword_url'])
        self.input_post_result_search.SetValue(config['api_post_data_url'])

    def __del__(self):
        pass

    # Virtual event handlers, overide them in your derived class
    def input_get_key_work_change_path(self, event):
        global config
        config['api_get_keyword_url'] = self.input_get_key_work_url.GetValue()
        with open(config_file, 'w') as outfile:
            yaml.dump(config, outfile, default_flow_style=False)

    def input_push_key_work_change_path(self, event):
        global config
        config['api_post_data_url'] = self.input_post_result_search.GetValue()
        with open(config_file, 'w') as outfile:
            yaml.dump(config, outfile, default_flow_style=False)

    def data_export_checkbox(self, event):
        event.Skip()

    def btn_run(self, event):
        if not self.thread_search:
            self.thread_search = GoogleSearchCore(list_result=self.list_result,url_get=self.input_get_key_work_url.GetValue().strip(),
                                                  url_post=self.input_post_result_search.GetValue().strip())
            self.thread_search.daemon = True
            self.thread_search.start()
            self.run_btn.SetLabel("Cancel")
            self.run_btn.SetBackgroundColour(wx.YELLOW)
        else:
            self.thread_search.stop()
            self.run_btn.SetLabel("Run")
            self.run_btn.SetBackgroundColour(wx.GREEN)


class GoogleSearchCore(Thread):
    def __init__(self, list_result: wx.ListCtrl, url_get: str, url_post: str):
        """Init Worker Thread Class."""
        Thread.__init__(self)
        self.stop_status = False
        self.url_get = url_get
        self.url_post = url_post
        self.list_result = list_result

    def search(self, keywords: dict, pause: int = 2):
        try:
            session = HTMLSession()
            session.get('https://www.google.com/?client=safari')
            time.sleep(2)
            link_position = list()
            url = f'https://www.google.com/search?client=safari&q={keywords["keyword"].replace(" ", "+")}&num=100'
            session_html = session.get(url, timeout=10)
            html_text = session_html.text
            if session_html.status_code == 429:
                row = self.list_result.ItemCount
                self.list_result.InsertStringItem(row, str(row))
                self.list_result.SetStringItem(row, 0, f"Error Captcha {str(session_html.status_code)}")
                logging.error(f"Error Captcha {str(session_html.status_code)}")
                time.sleep(60 * 5)
            soup = BeautifulSoup(html_text, 'html.parser')
            links_a = soup.findAll("div", {"class": "yuRUbf"})
            for index, link in enumerate(links_a):
                children = link.findChildren("a", recursive=False)
                for child in children:
                    link_position.insert(index, child['href'])

            # find index of the link
            for position, link in enumerate(link_position):
                if keywords['url'] in link:
                    logging.info(f"Found position of {keywords['keyword_id']} id is {position} position to server!")
                    # update UI Report
                    row = self.list_result.ItemCount
                    self.list_result.InsertStringItem(row, str(row))
                    self.list_result.SetStringItem(row, 1, str(position))
                    self.list_result.SetStringItem(row, 2, str(keywords['keyword']))
                    self.list_result.SetStringItem(row, 3, str(keywords['url']))
                    url_post = self.url_post.format(keyword_id=keywords['keyword_id'], position=position)
                    response = requests.get(url_post)
                    if response.status_code == 200:
                        self.list_result.SetStringItem(row, 4, 'Done')
                        logging.info(f"Push {keywords['keyword_id']} id, {position} position to server!")
                    else:
                        self.list_result.SetStringItem(row, 4, 'Error')
                    break
            logging.info(f"Waiting {pause} next request!")
            # sleep 2 then next search
            time.sleep(7)
        except Exception as err:
            logging.error(f"Error Captcha {str(err)}")
            time.sleep(60 * 5)

    def run(self):
        payload = {}
        headers = {}
        while True:
            response = requests.request("GET", self.url_get, headers=headers, data=payload)
            if response.status_code == 200:
                keywords_urls = json.loads(response.text)
                if keywords_urls['status']:
                    for key_word in keywords_urls['data']:
                        self.search(key_word)
            logging.info("Waiting 10s")
            time.sleep(10)
            # handle for request api
            if self.stop_status:
                return

    def stop(self):
        self.stop_status = True
